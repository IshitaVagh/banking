import { LitElement } from 'lit-element';
export declare class CustomerDetails extends LitElement {
    static styles: import("lit-element").CSSResult;
    Name: string;
    firstName: string;
    secoundName: string;
    lastName: string;
    city: string;
    state: string;
    country: string;
    showListFlag: boolean;
    listTemplate: string;
    render(): import("lit-element").TemplateResult;
    submitForm(): void;
}
//# sourceMappingURL=customer-details.d.ts.map