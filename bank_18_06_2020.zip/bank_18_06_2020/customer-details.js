var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { LitElement, html, customElement, property, css } from 'lit-element';
let CustomerDetails = class CustomerDetails extends LitElement {
    constructor() {
        super(...arguments);
        this.Name = "Ishita";
        this.firstName = "Ishita";
        this.secoundName = "S";
        this.lastName = "Vagh";
        this.city = "Surat";
        this.state = "Gujarat";
        this.country = "India";
        this.showListFlag = false;
        this.listTemplate = "";
    }
    render() {
        return html `
     
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
     <div class="container">
     <div class="row">
       <h4 style="text-align:center;"> Please Enter You Details </h4>
       <div class="col-sm-6 col-xs-12 col-md-3 wrap-input100 validate-input" data-validate="Name is required">
            <label class="label-input100" for="FirstName">First Name</label>
            <input id="firstName" class="input100" type="text" name="FirstName" .value="${this.firstName}"  @change=${(e) => this.firstName = e.target.value} placeholder="">
        </div>
        <div class="col-sm-6 col-xs-12 col-md-3 wrap-input100 validate-input" data-validate="Name is required">
            <label class="label-input100" for="middleName">Middle Name</label>
            <input id="name" class="input100" .value="${this.secoundName}" type="text" name="middleName"   @change=${(e) => this.secoundName = e.target.value} placeholder="">
        </div>
        <div class="col-sm-6 col-xs-12 col-md-3 wrap-input100 validate-input" data-validate="Name is required">
                <label class="label-input100" for="lastName">Last Name</label>
                <input id="name" class="input100" .value="${this.lastName}" type="text" name="lastName"  @change=${(e) => this.lastName = e.target.value}  placeholder="">
        </div>
        <div class="col-sm-6 col-xs-12 col-md-3 wrap-input100 validate-input" data-validate="Name is required">
            <label class="label-input100" for="HouseNo">House No/Flat No</label>
            <input id="name" class="input100" type="text" name="HouseNo" placeholder="">
        </div>
        <div class="col-sm-6 col-xs-12 col-md-3 wrap-input100 validate-input" data-validate="Name is required">
            <label class="label-input100" for="streetName">StreetName</label>
            <input id="name" class="input100" type="text" name="streetName" placeholder="">
        </div>
        <div class="col-sm-6 col-xs-12 col-md-3 wrap-input100 validate-input" data-validate="Name is required">
            <label class="label-input100" for="landmark">Land Mark</label>
            <input id="name" class="input100" type="text" name="landmark" placeholder="">
        </div>
        <div class="col-sm-6 col-xs-12 col-md-3 wrap-input100 validate-input" data-validate="Name is required">
            <label class="label-input100" for="city">city</label>
            <input id="name" class="input100" type="text" .value=${this.city} name="city"  @change=${(e) => this.city = e.target.value} placeholder="">
        </div>
        <div class="col-sm-6 col-xs-12 col-md-3 wrap-input100 validate-input" data-validate="Name is required">
            <label class="label-input100" for="State">State</label>
            <input id="name" class="input100" type="text" name="State" .value=${this.state}  @change=${(e) => this.state = e.target.value} placeholder="">
        </div>
        <div class="col-sm-6 col-xs-12 col-md-3 wrap-input100 validate-input" data-validate="Name is required">
            <label class="label-input100" for="country">country</label>
            <input id="name" class="input100" type="text" .value=${this.country}  @change=${(e) => this.country = e.target.value} name="country" placeholder="">
        </div>
       </div>
       <div class="col-sm-12 col-xs-12 col-md-12 submitButton">
            <button type="button" class="btn btn-primary filterbutton" @click=${this.submitForm}>
               Submit
            </button>
        </div>
        <div class="row submitSection">
        Details Entered is : <br/>
        ${this.showListFlag ? html `Name : ${this.firstName + " " + this.lastName} <br/> Address: ${this.city + " " + this.state + " " + this.country}` : html `<p> Details are Not Submited Yet </p>`}
      
        </div>
   </div>
     
     `;
    }
    submitForm() {
        this.showListFlag = true;
        // this.userDetails =  "";
    }
};
CustomerDetails.styles = css `
    .container{
        margin:0;
        width:100%;
        broder:1px solid #000;
        background: #ddd;
    }
    .input-text{
        border:1px solid #000;
        margin:5px;
        display:inline-block;
        height:30px;
      }
      .wrap-input100 {
        position: relative;
        border-radius: 10px;
        margin-bottom: 5px;
    }
    .label-input100 {
        font-size: 11px;
        color: #666666;
        line-height: 1.2;
        text-transform: uppercase;
        padding: 15px 0 2px 0;
    }
    label {
        display: block;
        margin: 0;
    }
    input.input100, select.input100 {
        height: 27px;
    }
    .detailbox
    .input100 {
        display: block;
        width: 100%;
        background: transparent;
        font-family: Montserrat-Regular;
        font-size: 18px;
        color: #404b46;
        border-bottom: 1px solid #000;
        line-height: 1.2;
        padding: 0 10px;
    }
    .submitButton{
        text-align:center;
    }
    .submitSection{
        text-align: center;
        padding: 15px;
        margin: 6%;
        background-color: #ddd;
        line-height: 16pt;
    }
    `;
__decorate([
    property({ type: String, reflect: true })
], CustomerDetails.prototype, "Name", void 0);
__decorate([
    property({ type: String, reflect: true })
], CustomerDetails.prototype, "firstName", void 0);
__decorate([
    property({ type: String, reflect: true })
], CustomerDetails.prototype, "secoundName", void 0);
__decorate([
    property({ type: String, reflect: true })
], CustomerDetails.prototype, "lastName", void 0);
__decorate([
    property({ type: String, reflect: true })
], CustomerDetails.prototype, "city", void 0);
__decorate([
    property({ type: String, reflect: true })
], CustomerDetails.prototype, "state", void 0);
__decorate([
    property({ type: String, reflect: true })
], CustomerDetails.prototype, "country", void 0);
__decorate([
    property({ type: Boolean, reflect: true })
], CustomerDetails.prototype, "showListFlag", void 0);
CustomerDetails = __decorate([
    customElement('customer-details')
], CustomerDetails);
export { CustomerDetails };
//# sourceMappingURL=customer-details.js.map