import {customElement,css,LitElement,html} from 'lit-element';

@customElement('userdetail-list')
export class UserdetailList extends LitElement{
    static styles= css``;
    render(){
        return html`
        <slot id="title"></slot>
        <slot id="download"></slot>
        <p> You are in Listing Page </p>
        `;
    }
}
