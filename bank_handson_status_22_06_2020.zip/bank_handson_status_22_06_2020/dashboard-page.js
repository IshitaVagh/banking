var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { LitElement, html, css, customElement } from 'lit-element';
let DashboardPage = class DashboardPage extends LitElement {
    render() {
        return html `<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
        <div class="container">
          <div class="row mainRow">
             <div class="col-md-2 sideNav">
             <div class="navLink">
              <a href="#"> Home</a>
              <a href="#"> Admin </a>
              <a href="#"> ATM Location </a>
              <a href="#"> Accounts </a>
              </div>
            </div>
            <div class="col-md-10">
              <customer-details></customer-details>
              <userdetail-list>
              <h3 slot="title"> Customer List </h3>
              <h5 slot="download"> Download section </h5>
              </userdetail-list>
      
            </div>
          </div>`;
    }
};
DashboardPage.styles = css `
      :host {
        display: block;
        max-width: 100%;
      }
     
      .container{
        margin:0;
        width:100%;
      }
      .mainRow{
        background:#ddd;
      }
    `;
DashboardPage = __decorate([
    customElement('dashboard-page')
], DashboardPage);
export { DashboardPage };
//# sourceMappingURL=dashboard-page.js.map