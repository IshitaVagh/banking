import { LitElement } from 'lit-element';
declare const AppMain_base: import("lit-element-router").Constructor<import("lit-element-router").Outlet> & typeof LitElement;
export declare class AppMain extends AppMain_base {
    render(): import("lit-element").TemplateResult;
}
export {};
//# sourceMappingURL=app-main.d.ts.map