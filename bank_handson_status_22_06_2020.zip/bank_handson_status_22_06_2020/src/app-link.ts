import { LitElement, html, property, customElement } from 'lit-element';
import { navigator } from 'lit-element-router';
@customElement('app-link')
export class Link extends navigator(LitElement) {
    @property({type:String})
    href="";
    constructor() {
        super();
        this.href = '';
    }
    render() {
        return html`
            <a href='${this.href}' @click='${()=>this.linkClick(event)}'>
                <slot></slot>
            </a>
        `;
    }
    linkClick(event:any) {
        event.preventDefault();
        this.navigate(this.href);
        console.log("hello World clicked");
    }
}
 