import {LitElement, html, property, customElement} from 'lit-element';
import {router} from 'lit-element-router';
import '/app-link.js';
import '/app-main.js';
@customElement('my-app')
export class MyApp extends router(LitElement){
  
  
    @property({type:String})
    route = "home";
    @property({type:Object})
    params = "";
    @property({type:Object})
    query = "";

    router(route:string,query:any,params:any,data:any){
        this.route= route;
        this.query = query;
        this.params = params;
        console.log(route, params, query, data);
    }
    static get routers(){
        return[{
            name: 'home',
            pattern:'',
            data:{name : 'ishita'}
        },
        {
            name: 'customer-detail',
            pattern:'',
            data:{name : 'ishita'}
        }]
    }
    render(){
        return html`
        <app-link href="/dev/home">Home</app-link>
        <app-link href="/dev/customer-details">Customer Details</app-link>
        <p> Routing ${this.route}</p>
        <app-main active-route=${this.route}> 
            <h1 route='home'>Home</h1>
            <h1 route='customer-details'>Customer Details</h1>
        </app-main>
        `;
    }
}