/**
 * @license
 * Copyright (c) 2019 The Polymer Project Authors. All rights reserved.
 * This code may only be used under the BSD style license found at
 * http://polymer.github.io/LICENSE.txt
 * The complete set of authors may be found at
 * http://polymer.github.io/AUTHORS.txt
 * The complete set of contributors may be found at
 * http://polymer.github.io/CONTRIBUTORS.txt
 * Code distributed by Google as part of the polymer project is also
 * subject to an additional IP rights grant found at
 * http://polymer.github.io/PATENTS.txt
 */

import {LitElement, html, customElement, property, css} from 'lit-element';
import '/customer-details.js';
import '/userdetail-list.js';
/**
 * An example element.
 *
 * @slot - This element has a slot
 * @csspart button - The button
 */
export const sideNavStyle= css`
.sideNav{
  margin:0;
  border:1px solid #000;
  text-align:center;
  height:100vh;
}
.sideNav a{
  display:block;
}
.navLink{
  margin:auto 0;
  padding: 50% 0;
}
`;
@customElement('my-element')
export class MyElement extends LitElement {
  static styles = css`
  ${sideNavStyle},
    :host {
      display: block;
      max-width: 100%;
    }
   
    .container{
      margin:0;
      width:100%;
    }
    .mainRow{
      background:#ddd;
    }
  `;

  /**
   * The name to say "Hello" to.
   */
  @property()
  name = 'World';

  /**
   * The number of times the button has been clicked.
   */
  @property({type: Number})
  count = 0;

  render() {
    return html`
    
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <div class="container">
      <div class="row mainRow">
         <div class="col-md-2 sideNav">
         <div class="navLink">
          <a href="#"> Home</a>
          <a href="#"> Admin </a>
          <a href="#"> ATM Location </a>
          <a href="#"> Accounts </a>
          </div>
        </div>
        <div class="col-md-10">
          <customer-details></customer-details>
          <userdetail-list>
          <h3 slot="title"> Customer List </h3>
          <h5 slot="download"> Download section </h5>
          </userdetail-list>
  
        </div>
      </div>
    `;
  }


  foo(): string {
    return 'foo';
  }
}

declare global {
  interface HTMLElementTagNameMap {
    'my-element': MyElement;
  }
}
