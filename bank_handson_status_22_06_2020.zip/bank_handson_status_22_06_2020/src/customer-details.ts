import {LitElement,html,customElement,property,css} from 'lit-element';
@customElement('customer-details')
export class CustomerDetails extends LitElement{
    static styles=css`
    .container{
        margin:0;
        width:100%;
        broder:1px solid #000;
        background: #ddd;
    }
    .input-text{
        border:1px solid #000;
        margin:5px;
        display:inline-block;
        height:30px;
      }
      .wrap-input100 {
        position: relative;
        border-radius: 10px;
        margin-bottom: 5px;
    }
    .label-input100 {
        font-size: 11px;
        color: #666666;
        line-height: 1.2;
        text-transform: uppercase;
        padding: 15px 0 2px 0;
    }
    label {
        display: block;
        margin: 0;
    }
    input.input100, select.input100 {
        height: 27px;
    }
    .detailbox
    .input100 {
        display: block;
        width: 100%;
        background: transparent;
        font-family: Montserrat-Regular;
        font-size: 18px;
        color: #404b46;
        border-bottom: 1px solid #000;
        line-height: 1.2;
        padding: 0 10px;
    }
    .submitButton{
        text-align:center;
    }
    .submitSection{
        text-align: center;
        padding: 15px;
        margin: 6%;
        background-color: #ddd;
        line-height: 16pt;
    }
    `;
    @property({type:String,reflect:true})
    Name = "Ishita";
    @property({type:String,reflect:true})
    firstName = "Ishita";
    @property({type:String,reflect:true})
    secoundName = "S";
    @property({type:String,reflect:true})
    lastName = "Vagh";
    @property({type:String,reflect:true})
    city = "Surat";
    @property({type:String,reflect:true})
    state = "Gujarat";
    @property({type:String,reflect:true})
    country = "India";
    @property({type:Boolean,reflect:true})
    showListFlag =false;
    listTemplate ="";
  render(){
     return html`
     
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
     <div class="container">
     <div class="row">
       <h4 style="text-align:center;"> Please Enter You Details </h4>
       <div class="col-sm-6 col-xs-12 col-md-3 wrap-input100 validate-input" data-validate="Name is required">
            <label class="label-input100" for="FirstName">First Name</label>
            <input id="firstName" class="input100" type="text" name="FirstName" .value="${this.firstName}"  @change=${(e:any) => this.firstName= e.target.value} placeholder="">
        </div>
        <div class="col-sm-6 col-xs-12 col-md-3 wrap-input100 validate-input" data-validate="Name is required">
            <label class="label-input100" for="middleName">Middle Name</label>
            <input id="name" class="input100" .value="${this.secoundName}" type="text" name="middleName"   @change=${(e:any) => this.secoundName= e.target.value} placeholder="">
        </div>
        <div class="col-sm-6 col-xs-12 col-md-3 wrap-input100 validate-input" data-validate="Name is required">
                <label class="label-input100" for="lastName">Last Name</label>
                <input id="name" class="input100" .value="${this.lastName}" type="text" name="lastName"  @change=${(e:any) => this.lastName= e.target.value}  placeholder="">
        </div>
        <div class="col-sm-6 col-xs-12 col-md-3 wrap-input100 validate-input" data-validate="Name is required">
            <label class="label-input100" for="HouseNo">House No/Flat No</label>
            <input id="name" class="input100" type="text" name="HouseNo" placeholder="">
        </div>
        <div class="col-sm-6 col-xs-12 col-md-3 wrap-input100 validate-input" data-validate="Name is required">
            <label class="label-input100" for="streetName">StreetName</label>
            <input id="name" class="input100" type="text" name="streetName" placeholder="">
        </div>
        <div class="col-sm-6 col-xs-12 col-md-3 wrap-input100 validate-input" data-validate="Name is required">
            <label class="label-input100" for="landmark">Land Mark</label>
            <input id="name" class="input100" type="text" name="landmark" placeholder="">
        </div>
        <div class="col-sm-6 col-xs-12 col-md-3 wrap-input100 validate-input" data-validate="Name is required">
            <label class="label-input100" for="city">city</label>
            <input id="name" class="input100" type="text" .value=${this.city} name="city"  @change=${(e:any) => this.city= e.target.value} placeholder="">
        </div>
        <div class="col-sm-6 col-xs-12 col-md-3 wrap-input100 validate-input" data-validate="Name is required">
            <label class="label-input100" for="State">State</label>
            <input id="name" class="input100" type="text" name="State" .value=${this.state}  @change=${(e:any) => this.state= e.target.value} placeholder="">
        </div>
        <div class="col-sm-6 col-xs-12 col-md-3 wrap-input100 validate-input" data-validate="Name is required">
            <label class="label-input100" for="country">country</label>
            <input id="name" class="input100" type="text" .value=${this.country}  @change=${(e:any) => this.country= e.target.value} name="country" placeholder="">
        </div>
       </div>
       <div class="col-sm-12 col-xs-12 col-md-12 submitButton">
            <button type="button" class="btn btn-primary filterbutton" @click=${this.submitForm}>
               Submit
            </button>
        </div>
        <div class="row submitSection">
        Details Entered is : <br/>
        ${
            
            this.showListFlag ? html`Name : ${this.firstName + " " +this.lastName} <br/> Address: ${this.city + " " +this.state + " " +this.country}`  : html`<p> Details are Not Submited Yet </p>`
        }
      
        </div>
   </div>
     
     `

  }
submitForm(){
      this.showListFlag= true;
       // this.userDetails =  "";
  }
}


