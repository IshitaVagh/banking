import {LitElement,html,css, customElement} from 'lit-element';

@customElement('dashboard-page')
export class DashboardPage extends LitElement{
    static styles = css`
      :host {
        display: block;
        max-width: 100%;
      }
     
      .container{
        margin:0;
        width:100%;
      }
      .mainRow{
        background:#ddd;
      }
    `;
    render(){
        return html `<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
        <div class="container">
          <div class="row mainRow">
             <div class="col-md-2 sideNav">
             <div class="navLink">
              <a href="#"> Home</a>
              <a href="#"> Admin </a>
              <a href="#"> ATM Location </a>
              <a href="#"> Accounts </a>
              </div>
            </div>
            <div class="col-md-10">
              <customer-details></customer-details>
              <userdetail-list>
              <h3 slot="title"> Customer List </h3>
              <h5 slot="download"> Download section </h5>
              </userdetail-list>
      
            </div>
          </div>`; 
    }

}

