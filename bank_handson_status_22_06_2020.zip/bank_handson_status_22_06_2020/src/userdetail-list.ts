import {customElement,css,LitElement,html} from 'lit-element';
import '/customer-details.js';
import '/userdetail-list.js';
/**
 * An example element.
 *
 * @slot - This element has a slot
 * @csspart button - The button
 */
export const sideNavStyle= css`
.sideNav{
  margin:0;
  border:1px solid #000;
  text-align:center;
  height:100vh;
}
.sideNav a{
  display:block;
}
.navLink{
  margin:auto 0;
  padding: 50% 0;
}
`;
@customElement('userdetail-list')
export class UserdetailList extends LitElement{
    
    static styles= css``;
    render(){
        return html`
        <slot id="title"></slot>
        <slot id="download"></slot>
        <p> You are in Listing Page </p>
        `;
    }
}
