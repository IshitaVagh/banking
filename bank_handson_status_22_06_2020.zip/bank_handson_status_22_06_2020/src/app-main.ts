import {LitElement,html, customElement} from 'lit-element';
import { outlet } from 'lit-element-router';
@customElement('app-main')
export class AppMain extends outlet(LitElement){
    render(){
        return html`
        <slot></slot>
        `
    }


}