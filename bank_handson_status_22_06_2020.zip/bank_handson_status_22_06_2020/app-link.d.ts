import { LitElement } from 'lit-element';
declare const Link_base: import("lit-element-router").Constructor<import("lit-element-router").Navigator> & typeof LitElement;
export declare class Link extends Link_base {
    href: string;
    constructor();
    render(): import("lit-element").TemplateResult;
    linkClick(event: any): void;
}
export {};
//# sourceMappingURL=app-link.d.ts.map