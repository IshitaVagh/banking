var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { LitElement, html, property, customElement } from 'lit-element';
import { router } from 'lit-element-router';
import '/app-link.js';
import '/app-main.js';
let MyApp = class MyApp extends router(LitElement) {
    constructor() {
        super(...arguments);
        this.route = "home";
        this.params = "";
        this.query = "";
    }
    router(route, query, params, data) {
        this.route = route;
        this.query = query;
        this.params = params;
        console.log(route, params, query, data);
    }
    static get routers() {
        return [{
                name: 'home',
                pattern: '',
                data: { name: 'ishita' }
            },
            {
                name: 'customer-detail',
                pattern: '',
                data: { name: 'ishita' }
            }];
    }
    render() {
        return html `
        <app-link href="/dev/home">Home</app-link>
        <app-link href="/dev/customer-details">Customer Details</app-link>
        <p> Routing ${this.route}</p>
        <app-main active-route=${this.route}> 
            <h1 route='home'>Home</h1>
            <h1 route='customer-details'>Customer Details</h1>
        </app-main>
        `;
    }
};
__decorate([
    property({ type: String })
], MyApp.prototype, "route", void 0);
__decorate([
    property({ type: Object })
], MyApp.prototype, "params", void 0);
__decorate([
    property({ type: Object })
], MyApp.prototype, "query", void 0);
MyApp = __decorate([
    customElement('my-app')
], MyApp);
export { MyApp };
//# sourceMappingURL=my-app.js.map