import { LitElement } from 'lit-element';
import '/app-link.js';
import '/app-main.js';
declare const MyApp_base: import("lit-element-router").Constructor<import("lit-element-router").Router> & typeof LitElement;
export declare class MyApp extends MyApp_base {
    route: string;
    params: string;
    query: string;
    router(route: string, query: any, params: any, data: any): void;
    static get routers(): {
        name: string;
        pattern: string;
        data: {
            name: string;
        };
    }[];
    render(): import("lit-element").TemplateResult;
}
export {};
//# sourceMappingURL=my-app.d.ts.map