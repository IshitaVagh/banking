import { LitElement } from 'lit-element';
export declare class DashboardPage extends LitElement {
    static styles: import("lit-element").CSSResult;
    render(): import("lit-element").TemplateResult;
}
//# sourceMappingURL=dashboard-page.d.ts.map