import { LitElement } from 'lit-element';
import '/customer-details.js';
import '/userdetail-list.js';
/**
 * An example element.
 *
 * @slot - This element has a slot
 * @csspart button - The button
 */
export declare const sideNavStyle: import("lit-element").CSSResult;
export declare class UserdetailList extends LitElement {
    static styles: import("lit-element").CSSResult;
    render(): import("lit-element").TemplateResult;
}
//# sourceMappingURL=userdetail-list.d.ts.map