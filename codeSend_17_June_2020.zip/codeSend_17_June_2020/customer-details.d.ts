import { LitElement } from 'lit-element';
import '/userdetail-list.js';
export declare class CustomerDetails extends LitElement {
    static styles: import("lit-element").CSSResult;
    Name: string;
    userDetails: {
        firstName: string;
        secoundName: string;
        lastName: string;
        city: string;
        state: string;
        country: string;
    };
    showListFlag: boolean;
    listTemplate: string;
    render(): import("lit-element").TemplateResult;
    submitForm(event: any): void;
}
//# sourceMappingURL=customer-details.d.ts.map