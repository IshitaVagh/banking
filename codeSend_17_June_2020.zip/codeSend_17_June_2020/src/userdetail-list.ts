import {customElement,css,LitElement,html} from 'lit-element';

@customElement('userdetail-list')
export class UserdetailList extends LitElement{
    static styles= css``;
    render(){
        return html`
        <p> You are in Listing Page </p>
        `;
    }
}
