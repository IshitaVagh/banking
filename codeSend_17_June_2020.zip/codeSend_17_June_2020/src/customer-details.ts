import {LitElement,html,customElement,property,css} from 'lit-element';
import '/userdetail-list.js';
@customElement('customer-details')
export class CustomerDetails extends LitElement{
    static styles=css`
    .container{
        margin:0;
        width:100%;
    }
    .input-text{
        border:1px solid #000;
        margin:5px;
        display:inline-block;
        height:30px;
      }
      .wrap-input100 {
        position: relative;
        border-radius: 10px;
        margin-bottom: 5px;
    }
    .label-input100 {
        font-size: 11px;
        color: #666666;
        line-height: 1.2;
        text-transform: uppercase;
        padding: 15px 0 2px 0;
    }
    label {
        display: block;
        margin: 0;
    }
    input.input100, select.input100 {
        height: 27px;
    }
    
    .input100 {
        display: block;
        width: 100%;
        background: transparent;
        font-family: Montserrat-Regular;
        font-size: 18px;
        color: #404b46;
        border-bottom: 1px solid #000;
        line-height: 1.2;
        padding: 0 10px;
    }
    .submitButton{
        text-align:center;
    }
    `;
    @property({type:String,reflect:true})
    Name = "Ishita";
    @property({type:Object,reflect:true})
    userDetails={'firstName':'Ishita',
                'secoundName':'',
                'lastName':'Vagh',
                'city':'',
                'state':'',
                'country':''};
    @property({type:Boolean,reflect:true})
    showListFlag =false;
    listTemplate ="";
  render(){
     return html`
     
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
     <div class="container">
     <h3>Hello, ${this.Name}!</h3>
     <div class="row">
       <h4 style="text-align:center;"> Please Enter You Details </h4>
       <div class="col-sm-6 col-xs-12 col-md-3 wrap-input100 validate-input" data-validate="Name is required">
            <label class="label-input100" for="FirstName">First Name</label>
            <input id="name" class="input100" type="text" name="FirstName" .value="${this.userDetails.firstName}" placeholder="">
        </div>
        <div class="col-sm-6 col-xs-12 col-md-3 wrap-input100 validate-input" data-validate="Name is required">
            <label class="label-input100" for="middleName">Middle Name</label>
            <input id="name" class="input100" .value="${this.userDetails.secoundName}" type="text" name="middleName" placeholder="">
        </div>
        <div class="col-sm-6 col-xs-12 col-md-3 wrap-input100 validate-input" data-validate="Name is required">
                <label class="label-input100" for="lastName">Last Name</label>
                <input id="name" class="input100" .value="${this.userDetails.lastName}" type="text" name="lastName" placeholder="">
        </div>
        <div class="col-sm-6 col-xs-12 col-md-3 wrap-input100 validate-input" data-validate="Name is required">
            <label class="label-input100" for="HouseNo">House No/Flat No</label>
            <input id="name" class="input100" type="text" name="HouseNo" placeholder="">
        </div>
        <div class="col-sm-6 col-xs-12 col-md-3 wrap-input100 validate-input" data-validate="Name is required">
            <label class="label-input100" for="streetName">StreetName</label>
            <input id="name" class="input100" type="text" name="streetName" placeholder="">
        </div>
        <div class="col-sm-6 col-xs-12 col-md-3 wrap-input100 validate-input" data-validate="Name is required">
            <label class="label-input100" for="landmark">Land Mark</label>
            <input id="name" class="input100" type="text" name="landmark" placeholder="">
        </div>
        <div class="col-sm-6 col-xs-12 col-md-3 wrap-input100 validate-input" data-validate="Name is required">
            <label class="label-input100" for="city">city</label>
            <input id="name" class="input100" type="text" .value=${this.userDetails.city} name="city" placeholder="">
        </div>
        <div class="col-sm-6 col-xs-12 col-md-3 wrap-input100 validate-input" data-validate="Name is required">
            <label class="label-input100" for="State">State</label>
            <input id="name" class="input100" type="text" name="State" .value=${this.userDetails.state} placeholder="">
        </div>
        <div class="col-sm-6 col-xs-12 col-md-3 wrap-input100 validate-input" data-validate="Name is required">
            <label class="label-input100" for="country">country</label>
            <input id="name" class="input100" type="text" .value=${this.userDetails.country} name="country" placeholder="">
        </div>
       </div>
       <div class="col-sm-12 col-xs-12 col-md-12 submitButton">
            <button type="button" class="btn btn-primary filterbutton" @click=${this.submitForm}>
               Submit
            </button>
        </div>
        <div class="row">
        Details Entered Are : 
        ${
            this.userDetails.firstName + "" +  this.userDetails.lastName
            
        }
        <userdetail-list></userdetail-list>
        </div>
   </div>
     
     `

  }
submitForm(event:any){
        console.log(event);
        if(this.userDetails !== undefined){
            this.showListFlag =true;
            console.log(this.userDetails);
        }
       // this.userDetails =  "";
  }
}


