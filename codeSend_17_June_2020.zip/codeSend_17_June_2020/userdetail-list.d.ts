import { LitElement } from 'lit-element';
export declare class UserdetailList extends LitElement {
    static styles: import("lit-element").CSSResult;
    render(): import("lit-element").TemplateResult;
}
//# sourceMappingURL=userdetail-list.d.ts.map